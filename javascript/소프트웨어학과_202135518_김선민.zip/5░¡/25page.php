<!DOCTYPE html>
<html>
<head>
<title>My PHP</title>
<style>body{font-family:times;}</style>
</head>
<body>
<p>Today is: <?php echo date("y/m/d") ?><br/>
Current time is: <?php echo date("h:i:sa") ?> </p>
</body>
</html>
