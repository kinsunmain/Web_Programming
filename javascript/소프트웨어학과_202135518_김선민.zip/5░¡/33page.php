<?php
echo "Hello World!<br>";
echo "This spans
multiple lines. The newlines will be
output as well.<br>";
echo "This spans<br>nmultiple lines. the newlines will be<br>noutput as well.<br>";
echo "Escaping characters is done <br> Like this.";
echo "<br>";
?>