<!DOCTYPE html>
<html>
<head>
<title>My PHP</title>
</head>
<body>
<?php
echo "<h3>Hi, this is myFirst php!</h3>";
?>
</body>
</html>
